/**
 * Gemini AI Service — gọi Gemini API (free) thay vì Amazon Bedrock
 *
 * Dùng URL: https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
 * API key từ GEMINI_API_KEY env var.
 *
 * @module lambdas/ai-processing/geminiService
 */

const GEMINI_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';

/**
 * Gọi Gemini API để generate content.
 *
 * @param {string} model — ví dụ "gemini-2.0-flash" (free, nhanh)
 * @param {string} prompt — system prompt + user message
 * @param {Object} [opts] — { temperature, maxOutputTokens }
 * @returns {Promise<string>} text response
 */
export async function callGemini(model, prompt, opts = {}) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY not configured — set in Lambda env var or Secrets Manager');
  }

  const url = `${GEMINI_BASE}/${model}:generateContent?key=${apiKey}`;
  const temperature = opts.temperature ?? 0.3;
  const maxOutputTokens = opts.maxOutputTokens ?? 4096;

  const body = {
    contents: [
      {
        parts: [{ text: prompt }],
      },
    ],
    generationConfig: {
      temperature,
      maxOutputTokens,
    },
  };

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Gemini API error ${response.status}: ${errText}`);
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text || '';

  if (!text) {
    throw new Error('Gemini returned empty response — check prompt or quota');
  }

  return text;
}

/**
 * Hàm tiện ích: bóc ```json ... ``` khỏi response nếu có.
 */
export function extractJson(text) {
  const cleaned = text
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
  try {
    return JSON.parse(cleaned);
  } catch {
    // Nếu vẫn lỗi, thử tìm mảng JSON trong text
    const match = cleaned.match(/\[[\s\S]*?\]/);
    if (match) return JSON.parse(match[0]);
    throw new Error(`Cannot parse Gemini response as JSON: ${text.slice(0, 200)}...`);
  }
}

// ─── Prompt Templates ──────────────────────────────────

export const SYSTEM_PROMPT_SUMMARIZE = `Bạn là trợ lý phân tích cuộc họp chuyên nghiệp.

Hãy phân tích transcript cuộc họp dưới đây và trả về:
1. Tóm tắt ngắn gọn bằng tiếng Việt (summary)
2. Các quyết định quan trọng (keyDecisions)
3. Các rủi ro / vấn đề cần theo dõi (risks)

CHỈ trả về JSON, không thêm chữ nào khác:
{
  "summary": "...",
  "keyDecisions": ["...", "..."],
  "risks": ["...", "..."]
}`;

export const SYSTEM_PROMPT_ANALYZE = `Bạn là trợ lý phân tích cuộc họp chuyên nghiệp.

Dựa vào transcript cuộc họp dưới đây, hãy phân tích và trả về:
1. Tóm tắt ngắn gọn bằng tiếng Việt (summary)
2. Các quyết định quan trọng (keyDecisions)
3. Danh sách công việc cần làm (tasks) — mỗi task có title, description, assignee (nếu có), priority (HIGH/MEDIUM/LOW), deadline (nếu có)
4. Các rủi ro / vấn đề cần theo dõi (risks)

CHỈ trả về JSON, không thêm chữ nào khác:
{
  "summary": "...",
  "keyDecisions": ["...", "..."],
  "tasks": [
    {
      "title": "Tên công việc",
      "description": "Mô tả chi tiết",
      "assignee": "Tên người được giao (nếu có)",
      "priority": "HIGH|MEDIUM|LOW",
      "deadline": "YYYY-MM-DD (nếu có)"
    }
  ],
  "risks": ["...", "..."]
}

Nguyên tắc:
- Chỉ lấy thông tin được đề cập rõ ràng trong transcript
- Nếu không có ai được giao, để assignee là rỗng
- Nếu không có deadline, để deadline là rỗng
- Tóm tắt ngắn gọn, đủ ý chính`;

export const SYSTEM_PROMPT_TASKS = `Bạn là trợ lý chia việc từ cuộc họp.

Dựa vào transcript và summary dưới đây, hãy trích xuất danh sách công việc cần làm.

CHỈ trả về JSON array, không thêm chữ nào khác:
[
  {
    "title": "Tên công việc",
    "description": "Mô tả chi tiết",
    "assignee": "Tên người được giao (nếu có)",
    "priority": "HIGH|MEDIUM|LOW",
    "deadline": "YYYY-MM-DD (nếu có)"
  }
]

Nguyên tắc:
- Chỉ lấy công việc được đề cập rõ ràng
- Nếu không có ai được giao, để assignee là rỗng
- Nếu không có deadline, để deadline là rỗng`;

export default { callGemini, extractJson };
