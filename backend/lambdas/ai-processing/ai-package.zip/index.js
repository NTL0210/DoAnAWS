/**
 * AI Process Lambda — Layer 3 (Transcribe + Prompt+Gemini)
 *
 * Actions:
 *   transcribe          — Start Transcribe job (vi-VN)
 *   check-transcription — Poll Transcribe status
 *   analyze             — Đọc transcript S3 → Gemini → result
 *
 * @module lambdas/ai-processing/index
 */

import {
  S3Client,
  GetObjectCommand,
} from '@aws-sdk/client-s3';
import {
  TranscribeClient,
  StartTranscriptionJobCommand,
  GetTranscriptionJobCommand,
} from '@aws-sdk/client-transcribe';
import {
  DynamoDBClient,
  UpdateItemCommand,
} from '@aws-sdk/client-dynamodb';
import { callGemini, extractJson, SYSTEM_PROMPT_ANALYZE } from './geminiService.js';

const { TABLE_NAME, AWS_REGION, GEMINI_MODEL } = process.env;
const s3 = new S3Client({ region: AWS_REGION || 'ap-southeast-1' });
const transcribe = new TranscribeClient({ region: AWS_REGION || 'ap-southeast-1' });
const ddb = new DynamoDBClient({ region: AWS_REGION || 'ap-southeast-1' });
const MODEL = GEMINI_MODEL || 'gemini-2.0-flash';

export async function handler(event) {
  console.log('[Process] Event:', JSON.stringify(event));

  const { action, meetingId, storageKey, bucket, transcriptText, jobName, outputKey, transcript, transcriptKey } = event;

  try {
    switch (action) {
      case 'transcribe':
        return await startTranscribe(meetingId, storageKey, bucket, transcriptText);
      case 'check-transcription':
        return await checkTranscribe(meetingId, jobName, bucket, outputKey);
      case 'analyze':
      default:
        return await analyzeWithGemini(meetingId, bucket, transcriptKey || '');
    }
  } catch (err) {
    console.error(`[Process] Error:`, err);
    throw err;
  }
}

/** Start Transcribe job */
async function startTranscribe(meetingId, storageKey, bucket, transcriptText) {
  if (transcriptText) return { meetingId, transcript: transcriptText, status: 'TRANSCRIBED' };
  if (!storageKey) throw new Error('storageKey is required');

  if (storageKey.endsWith('.txt') || storageKey.endsWith('.md')) {
    const text = await readFromS3(bucket, storageKey);
    return { meetingId, transcript: text, status: 'TRANSCRIBED' };
  }

  const jobName = `am-${meetingId}-${Date.now()}`;
  const format = storageKey.split('.').pop() || 'mp3';

  await transcribe.send(new StartTranscriptionJobCommand({
    TranscriptionJobName: jobName,
    LanguageCode: 'vi-VN',
    MediaFormat: format,
    Media: { MediaFileUri: `s3://${bucket}/${storageKey}` },
    OutputBucketName: bucket,
    OutputKey: `transcripts/${meetingId}.json`,
    Settings: { ShowSpeakerLabels: true, MaxSpeakerLabels: 10 },
  }));

  return { meetingId, jobName, status: 'TRANSCRIBING', outputKey: `transcripts/${meetingId}.json` };
}

/** Check Transcribe job status */
async function checkTranscribe(meetingId, jobName, bucket, outputKey) {
  if (!jobName && outputKey) {
    const text = await readFromS3(bucket, outputKey);
    if (text) return { meetingId, transcript: text, status: 'TRANSCRIBED' };
  }
  if (!jobName) throw new Error('jobName required');

  const result = await transcribe.send(new GetTranscriptionJobCommand({
    TranscriptionJobName: jobName,
  }));
  const job = result.TranscriptionJob;

  if (job.TranscriptionJobStatus === 'COMPLETED') {
    let text = '';
    try {
      const data = await readFromS3(bucket, `transcripts/${meetingId}.json`);
      const parsed = JSON.parse(data);
      text = parsed.results?.transcripts?.[0]?.transcript || data;
    } catch { text = 'Unable to read transcript'; }
    return { meetingId, transcript: text, status: 'TRANSCRIBED' };
  }
  if (job.TranscriptionJobStatus === 'FAILED') {
    throw new Error(`Transcribe failed: ${job.FailureReason || 'Unknown'}`);
  }
  return { meetingId, jobName, status: 'TRANSCRIBING' };
}

/** Read transcript from S3 + call Gemini */
async function analyzeWithGemini(meetingId, bucket, transcriptKey) {
  if (!transcriptKey) throw new Error('transcriptKey is required');

  const raw = await readFromS3(bucket, transcriptKey);
  let text = raw;
  try { const p = JSON.parse(raw); text = p.results?.transcripts?.[0]?.transcript || raw; } catch {}

  if (!text.trim()) throw new Error('Empty transcript');

  if (!process.env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY not configured');

  const prompt = `${SYSTEM_PROMPT_ANALYZE}\n\nTranscript:\n${text.slice(0, 30000)}`;
  const geminiRaw = await callGemini(MODEL, prompt, { temperature: 0.3, maxOutputTokens: 4096 });
  const result = extractJson(geminiRaw);

  return {
    meetingId,
    summary: result.summary || '',
    keyDecisions: result.keyDecisions || [],
    tasks: result.tasks || [],
    risks: result.risks || [],
    status: 'ANALYZED',
    model: MODEL,
  };
}

async function readFromS3(bucket, key) {
  const r = await s3.send(new GetObjectCommand({ Bucket: bucket, Key: key }));
  return await r.Body.transformToString('utf-8');
}

export default { handler };
